# PeliculasApp

Aplicacion creada con angular2 y nos conectamos a la api de https://www.themoviedb.org para hacer consultas de
las películas que están en cartelera, más populares, populares para niños.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Notas adicionales
Utilizamos jsonp para poder hacer las consultas a otros dominios y así no obtener el error de cross-domain.
